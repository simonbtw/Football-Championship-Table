package footballChampionship;
//abstract class
public abstract class Sports_Club {
    
}
