package footballChampionship;
//interface
public interface League_Manager {
    void sortingpoints();
    void sortingWins();
    public void sortingGoalScore();
}
