package footballChampionship;
//import required utilities
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class Premier_League_Manager extends Football_Club implements League_Manager{
int len = 0;
    public Premier_League_Manager() {
        Clubs_Name = new String[100];
        Clubs_Location = new String[100];
        Clubs_Wins = new int[100];
        Clubs_Draws = new int[100];
        Clubs_Defeats = new int[100];
        Clubs_Instance_Acheived_in_Season = new int[100];
        Clubs_Goals_Received = new int[100];
        Clubs_Goals_Scored = new int[100];
        Clubs_Number = new int[100];
        Clubs_No_Of_Mathes_Played = new int[100];
    }
    
    
    public static void main(String[] args){
        Premier_League_Manager pml = new Premier_League_Manager();
        System.out.println("Welcome to Football Championship");
        pml.displayMenu();   //function called to show menu for choice
    }
    public void displayMenu(){
        //Declairing variables and Object for input
        Scanner input = new Scanner(System.in);
        int i = 0;
        int choice = 0; //For menu choice
        int j = 0;
        while(true){
            //Menu Messages
            System.out.println("\n1.Create a Football Club (will also be Added in Premier League)");
            System.out.println("2.Delete an Existing Club from Premier League");
            System.out.println("3.Display the Statistics (Select a Club by input name)");
            System.out.println("4.Display Premier League Table");
            System.out.println("5.Add a Played Match");
            System.out.println("6.Start Graphical User Interface (GUI)");
            System.out.println("7.Exit");
            System.out.print("Enter Your Choice? ");
            choice = input.nextInt(); //Take input from user by menu option
            
            //Add Club in the premier league, showing messages with instructions.
            if (choice == 1) {
                System.out.print("Enter Club Name? ");
                Club_Name = input.next();
                System.out.print("Enter Club Location? ");
                Club_Location = input.next();
                System.out.print("Enter number of Club Wins? (In Numbers)");
                Club_Wins = input.nextInt();
                System.out.print("Enter number of Club Draws? (In Numbers)");
                Club_Draws = input.nextInt();
                System.out.print("Enter number of Club Defeats? (In Numbers)");
                Club_Defeats = input.nextInt();
                System.out.print("Enter Instance Achieved in Season of Club? (In Numbers)");
                Club_Instance_Acheived_in_Season = input.nextInt();
                System.out.print("Enter number of Goals Received by Club? (In Numbers)");
                Club_Goals_Received = input.nextInt();
                System.out.print("Enter number of Goals Scored by Club? (In Numbers)");
                Club_Goals_Scored = input.nextInt();
                System.out.print("Enter number of Points Club Currently have? (In Numbers)");
                Club_Number = input.nextInt();
                System.out.print("Enter number of Club Matches? (In Numbers)");
                Club_No_Of_Mathes_Played = input.nextInt();
                
                //Write in the file
                File obj = new File("teamsData.txt");
                try {
                     FileWriter myWriter = new FileWriter("teamsData.txt", true);
                     myWriter.write(Club_Name+","+Club_Location+","+Club_Wins+","+Club_Draws+","+Club_Defeats+","+Club_Instance_Acheived_in_Season+","+Club_Goals_Received+","+Club_Goals_Scored+","+Club_Number+","+Club_No_Of_Mathes_Played+"\n");
                     myWriter.close();
                     System.out.println("Successfully Added");                     
                  } catch (IOException e) {
                    System.out.println("UnSuccessfully Added");                     
                  }
                System.out.println("Enter any character to Main Menu....");
                String enter = input.next();               
            }
            //Delete the selected club
            else if (choice == 2) {
                System.out.println("Enter club name that you want to delete? ");
                String name = input.next();
                Scanner scanner;
                File file = new File("teamsData.txt");
                try {
                    String[] arr = new String[1000];
                    scanner = new Scanner(file).useDelimiter( ",");
                    int inc = 0;
                    //Searching for selected club
                    while (scanner.hasNext()) {
                        final String lineFromFile = scanner.nextLine();
                        if (lineFromFile.contains(name)) {
                            
                        }else{
                            arr[inc] = lineFromFile;
                            inc++;
                            len++;
                        }
                    }
                    for (int k = 0; k < len; k++) {
                        System.out.println(arr[k]);
                    }
                    //After deletion rewrite on file
                    PrintWriter writer = new PrintWriter(file);
                    writer.print("");
                    writer.close();
                    File obj = new File("teamsData.txt");
                try {
                     FileWriter myWriter = new FileWriter("teamsData.txt", true);  //create object of file writer
                     for (int k = 0; k < len; k++) {
                         myWriter.write(arr[k]+"\n");
                    }
                     
                     myWriter.close();
                     System.out.println("Successfully wrote to the file.");
                  } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                  }
                } catch (IOException e) {
                    System.out.println(" cannot write to file " + file.toString());
                }
                len = 0;
                System.out.println("Enter any character to Main Menu....");
                String enter = input.next();

            }
            //See the statistice of selected club
            else if (choice == 3) {
                System.out.println("Enter club name that you want to See? ");
                String name = input.next();
                Scanner scanner;
                File file = new File("teamsData.txt");
                try {

                    scanner = new Scanner(file).useDelimiter( ",");
                    //Searching for club
                    while (scanner.hasNext()) {
                        final String lineFromFile = scanner.nextLine();
                        if (lineFromFile.contains(name)) {
                            String[] line = lineFromFile.split(",");                
                            System.out.println("Statistics of " + name+" is:");
                            System.out.println("Name: "+line[0]+"\nLocation: "+line[1]+"\nWins: "+line[2]+"\nDraws: "+line[3]+"\nDefeats: "+line[4]+"\nInstance acheived in season: "+line[5]+"\nGoals Received: "+line[6]+"\nGoals Scored: "+line[7]+"\nNumber of Points: "+line[8]+"\nNumber of matches: "+line[9]);
                            break;
                        }
                    }
                } catch (IOException e) {
                    System.out.println(" cannot write to file " + file.toString());
                }
                System.out.println("Enter any character to Main Menu....");
                String enter = input.next();
            }
            //Sorting according to points
            else if (choice == 4) {                             
                sortingpoints(); //calling functions
            }
            //Adding played matches...
            else if (choice == 5) {
                 System.out.println("Enter first team name? ");
                 String name1 = input.next();
                 System.out.println("Enter first team Score? ");
                 int score1 = input.nextInt();
                 System.out.println("Enter Second team name? ");
                 String name2 = input.next();
                 System.out.println("Enter Second team Score? ");
                 int score2 = input.nextInt();
                 System.out.println("Enter Date of the Match? (format date-month-year) ");
                 String date = input.next();
                 File obj = new File("matchesPlayer.txt");     
                 String msg = null;
                 if (score1>score2) {
                    msg = name1+" win!";
                    Scanner scanner;
                     System.out.println("Premier Table update!");
                File file = new File("teamsData.txt");
                try {
                    String[] temp = new String[100];
                    int incr = 0;
                    scanner = new Scanner(file).useDelimiter( ",");

                    while (scanner.hasNext()) {
                        len++;
                        final String lineFromFile = scanner.nextLine();
                        if (lineFromFile.contains(name1)) {
                            String[] line = lineFromFile.split(",");
                            line[2] = ""+Integer.parseInt(line[2]) + 1;
                            line[8] = ""+Integer.parseInt(line[8]) + score1;
                            line[9] = ""+Integer.parseInt(line[9]) + 1;
                            //System.out.println("Name: "+line[0]+"\nLocation: "+line[1]+"\nWins: "+line[2]+"\nDraws: "+line[3]+"\nDefeats: "+line[4]+"\nInstance acheived in season: "+line[5]+"\nGoals Received: "+line[6]+"\nGoals Scored: "+line[7]+"\nNumber of Points: "+line[8]+"\nNumber of matches: "+line[9]);
                            temp[incr] = line[0]+","+line[1]+","+line[2]+","+line[3]+","+line[4]+","+line[5]+","+line[6]+","+line[7]+","+line[8]+","+line[9];
                            incr++;
                        }else if (lineFromFile.contains(name2)) {
                            String[] line = lineFromFile.split(",");
                            line[4] = ""+Integer.parseInt(line[4]) + 1;
                            line[8] = ""+Integer.parseInt(line[8]) + score2;
                            line[9] = ""+Integer.parseInt(line[9]) + 1;
                            //System.out.println("Name: "+line[0]+"\nLocation: "+line[1]+"\nWins: "+line[2]+"\nDraws: "+line[3]+"\nDefeats: "+line[4]+"\nInstance acheived in season: "+line[5]+"\nGoals Received: "+line[6]+"\nGoals Scored: "+line[7]+"\nNumber of Points: "+line[8]+"\nNumber of matches: "+line[9]);
                            temp[incr] = line[0]+","+line[1]+","+line[2]+","+line[3]+","+line[4]+","+line[5]+","+line[6]+","+line[7]+","+line[8]+","+line[9];
                            incr++;
                        } else{
                            temp[incr] = lineFromFile;
                            incr++;
                        }
                    }
                    PrintWriter writer = new PrintWriter(file);
                    writer.print("");
                    writer.close();
                    File obj1 = new File("teamsData.txt");
                try {
                     FileWriter myWriter = new FileWriter("teamsData.txt", true);
                     for (int k = 0; k < len; k++) {
                         myWriter.write(temp[k]+"\n");
                    }
                     
                     myWriter.close();
                     System.out.println("Successfully wrote to the file.");
                  } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                  }
                } catch (IOException e) {
                    System.out.println(" cannot write to file " + file.toString());
                }
                }else{
                     msg = name2+" win!";
                     Scanner scanner;
                     System.out.println("Premier Table update!");
                File file = new File("teamsData.txt");
                try {
                    String[] temp = new String[100];
                    int incr = 0;
                    scanner = new Scanner(file).useDelimiter( ",");

                    while (scanner.hasNext()) {
                        len++;
                        final String lineFromFile = scanner.nextLine();
                        if (lineFromFile.contains(name1)) {
                            String[] line = lineFromFile.split(",");
                            line[4] = ""+(Integer.parseInt(line[4]) + 1);
                            line[8] = ""+(Integer.parseInt(line[8]) + score1);
                            line[9] = ""+(Integer.parseInt(line[9]) + 1);
                            //System.out.println("Name: "+line[0]+"\nLocation: "+line[1]+"\nWins: "+line[2]+"\nDraws: "+line[3]+"\nDefeats: "+line[4]+"\nInstance acheived in season: "+line[5]+"\nGoals Received: "+line[6]+"\nGoals Scored: "+line[7]+"\nNumber of Points: "+line[8]+"\nNumber of matches: "+line[9]);
                            temp[incr] = line[0]+","+line[1]+","+line[2]+","+line[3]+","+line[4]+","+line[5]+","+line[6]+","+line[7]+","+line[8]+","+line[9];
                            incr++;
                        }else if (lineFromFile.contains(name2)) {
                            String[] line = lineFromFile.split(",");
                            line[2] = ""+(Integer.parseInt(line[2]) + 1);
                            line[8] = ""+(Integer.parseInt(line[8]) + score2);
                            line[9] = ""+(Integer.parseInt(line[9]) + 1);                            
                            temp[incr] = line[0]+","+line[1]+","+line[2]+","+line[3]+","+line[4]+","+line[5]+","+line[6]+","+line[7]+","+line[8]+","+line[9];
                            incr++;
                        } else{
                            temp[incr] = lineFromFile;
                            incr++;
                        }
                        
                    }
                    PrintWriter writer = new PrintWriter(file);
                    writer.print("");
                    writer.close();
                    File obj1 = new File("teamsData.txt");
                try {
                     FileWriter myWriter = new FileWriter("teamsData.txt", true);
                     for (int k = 0; k < len; k++) {
                         myWriter.write(temp[k]+"\n");
                    }
                     
                     myWriter.close();
                     System.out.println("Successfully wrote to the file.");
                  } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                  }
                } catch (IOException e) {
                    System.out.println(" cannot write to file " + file.toString());
                }
                 }
                try {
                     FileWriter myWriter = new FileWriter("matchesPlayer.txt", true);
                     myWriter.write(name1+","+score1+","+name2+","+score2+","+msg+","+date+"\n");
                     myWriter.close();
                     System.out.println("Successfully wrote to the file.");
                  } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                  }                                
            }
            //Open JFrame
            else if (choice == 6) {
                JFrame f=new JFrame();//creating instance of JFrame 
                
                JButton b1=new JButton("Teams: Sorting on the basis of Points");//creating instance of JButton  
                b1.setBounds(130,100,300, 50);//x axis, y axis, width, height
                b1.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){  
                    System.out.println("Done");
                    JFrame f2=new JFrame();
                    String[] column = {"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};         
                    Object[] objs2={"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};         
                    DefaultTableModel tableModel = new DefaultTableModel(column, 0);
                    sortingpoints();
                    System.out.println("1");
                    
                                            
                    JTable table = new JTable(tableModel);
                    System.out.println("Len: "+len);
                    tableModel.addRow(objs2);
                    for (int k = 0; k < len; k++) {
                        Object[] objs = {Clubs_Name[k],Clubs_Location[k],Clubs_Wins[k],Clubs_Draws[k],Clubs_Defeats[k],Clubs_Instance_Acheived_in_Season[k],Clubs_Goals_Received[k],Clubs_Goals_Scored[k],Clubs_Number[k],Clubs_No_Of_Mathes_Played[k]};
                        tableModel.addRow(objs);
                    }
                    len = 0;
                    f2.setTitle("Sorting on the basis of Points");
                    f2.add(table);
                    f2.setSize(1200,700);    
                    f2.setVisible(true);
            }  
            });  
                f.add(b1);//adding button in JFrame  
                
                
                JButton b2=new JButton("Teams: Sorting on the basis of Goals scores");//creating instance of JButton  
                b2.setBounds(130,175,300, 50);//x axis, y axis, width, height  
                b2.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){  
                    System.out.println("Done");
                    JFrame f3=new JFrame();
                    String[] column={"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};         
                    Object[] objs2={"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};
                    DefaultTableModel tableModel = new DefaultTableModel(column, 0);
                    sortingGoalScore();
                    System.out.println("1");
                    
                                            
                    JTable table = new JTable(tableModel);
                    tableModel.addRow(objs2);
                    System.out.println("Len: "+len);
                    
                    for (int k = 0; k < len; k++) {
                        if (k == 0) {
                            Object[] objs = {Clubs_Name[k],Clubs_Location[k],Clubs_Wins[k],Clubs_Draws[k],Clubs_Defeats[k],Clubs_Instance_Acheived_in_Season[k],Clubs_Goals_Received[k],Clubs_Goals_Scored[k],Clubs_Number[k],Clubs_No_Of_Mathes_Played[k]};
                            tableModel.addRow(objs);
                        }else{
                            Object[] objs = {Clubs_Name[k],Clubs_Location[k],Clubs_Wins[k],Clubs_Draws[k],Clubs_Defeats[k],Clubs_Instance_Acheived_in_Season[k],Clubs_Goals_Received[k],Clubs_Goals_Scored[k],Clubs_Number[k],Clubs_No_Of_Mathes_Played[k]};
                            tableModel.addRow(objs);
                        }
                        
                        
                    }
                    
                    len = 0;
                    f3.setTitle("Sorting on the basis of Goals Scored");
                    
                    f3.add(table);
                    f3.setSize(1200,700);    
                    f3.setVisible(true);
            }  
            });  
                f.add(b2);//adding button in JFrame
                JButton b3=new JButton("Teams: Sorting on the basis of Wins"); //creating instance of JButton  
                b3.setBounds(130,250,300, 50);//x axis, y axis, width, height  
                b3.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){  
                    System.out.println("Done");
                    JFrame f4=new JFrame();
                    String[] column={"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};         
                    Object[] objs2={"Name","Location","Wins","Draws","Defeats","Instance Point","Goals Received","Goals Scored","Points","No. of Matches"};
                    DefaultTableModel tableModel = new DefaultTableModel(column, 0);
                    sortingWins();
                    System.out.println("1");
                    
                                            
                    JTable table = new JTable(tableModel);
                    tableModel.addRow(objs2);
                    System.out.println("Len: "+len);
                    
                    for (int k = 0; k < len; k++) {
                        if (k == 0) {
                            Object[] objs = {Clubs_Name[k],Clubs_Location[k],Clubs_Wins[k],Clubs_Draws[k],Clubs_Defeats[k],Clubs_Instance_Acheived_in_Season[k],Clubs_Goals_Received[k],Clubs_Goals_Scored[k],Clubs_Number[k],Clubs_No_Of_Mathes_Played[k]};
                            tableModel.addRow(objs);
                        }else{
                            Object[] objs = {Clubs_Name[k],Clubs_Location[k],Clubs_Wins[k],Clubs_Draws[k],Clubs_Defeats[k],Clubs_Instance_Acheived_in_Season[k],Clubs_Goals_Received[k],Clubs_Goals_Scored[k],Clubs_Number[k],Clubs_No_Of_Mathes_Played[k]};
                            tableModel.addRow(objs);
                        }
                        
                        
                    }
                    len = 0;
                    f4.setTitle("Sorting on the basis of Wins");
                    f4.add(table);
                    f4.setSize(1200,700);    
                    f4.setVisible(true);
            }  
            });  
                
                JButton btn4 = new JButton("Random Match Generater");
                btn4.setBounds(130, 325, 300, 50);
                btn4.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){
                    Scanner scanner;
                    String[] names = new String[1000];
                File file = new File("teamsData.txt");
                try {

                    scanner = new Scanner(file).useDelimiter( ",");
                    
                    int incret = 0;
                    while (scanner.hasNext()) {
                        final String lineFromFile = scanner.nextLine();
                        String[] line = lineFromFile.split(",");
                        names[incret] = line[0];
                        len++;
                        incret++;
                    }
                    //System.out.println(len);
                } catch (IOException ee) {
                    System.out.println(" cannot write to file " + file.toString());
                }
                String msg = null;

                    Random rand = new Random();
                    int team1 = rand.nextInt(len/2);
                    int team2 = rand.nextInt(len/2);
                    int Score1 = rand.nextInt(100);
                    int Score2 = rand.nextInt(100);
                    
                    if (team1 == team2) {
                        team1 = rand.nextInt(len/2);
                    }
                    GregorianCalendar gc = new GregorianCalendar();
                    int year = randBetween(1900, 2010);
                    gc.set(gc.YEAR, year);
                    int dayOfYear = randBetween(1, gc.getActualMaximum(gc.DAY_OF_YEAR));
                    gc.set(gc.DAY_OF_YEAR, dayOfYear);
                    String date = gc.get(gc.DAY_OF_MONTH)+"-"+ (gc.get(gc.MONTH) + 1) +"-"+gc.get(gc.YEAR);
                    
                    
                    
                    
                    
                    
                    
                     if (Score1>=Score2) {
                        msg = names[team1]+" win!";
                        
                    }else{
                         msg = names[team2]+" win!";
                     }
                     
                     
                     File obj = new File("matchesPlayer.txt");
                    try {
                     FileWriter myWriter = new FileWriter("matchesPlayer.txt", true);
                     myWriter.write(names[team1]+","+Score1+","+names[team2]+","+Score2+","+msg+","+date+"\n");
                     myWriter.close();
                     System.out.println("Successfully Added");                     
                    } catch (IOException eee) {
                    System.out.println("UnSuccessfully Added");                     
                  }
            }  
            });
                
                
                
                f.add(b3);//adding button in JFrame
                f.add(btn4);
                JTextField jtext = new JTextField();
                jtext.setBounds(130, 400, 200, 40);
                f.add(jtext);
                
                JButton btnsearch = new JButton("Search");
                btnsearch.setBackground(Color.GRAY);
                btnsearch.setForeground(Color.WHITE);
                btnsearch.setBounds(350, 400, 100, 40);
                btnsearch.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){  
                    String[] team1,score1,team2,score2,msg;
                    team1 = new String[1000];
                    score1 = new String[1000];
                    team2 = new String[1000];
                    score2 = new String[1000];
                    msg = new String[1000];
                    System.out.println("Done");
                    JFrame f6=new JFrame();
                    String[] column={"Team1","Score1","Team2","Score2","Status"};         
                    Object[] objs2={"Team1","Score1","Team2","Score2","Status"};
                    DefaultTableModel tableModel = new DefaultTableModel(column, 0);
                    Scanner scanner;
                File file = new File("matchesPlayer.txt");
                try{
                    System.out.println("2");
                    scanner = new Scanner(file).useDelimiter( ",");
                    int k=0;
                    System.out.println("3");
                    while (scanner.hasNext()) {
                        
                        final String lineFromFile = scanner.nextLine();
                        if (lineFromFile.contains(jtext.getText())) {
                            len++;
                            String[] line = lineFromFile.split(",");
                            team1[k] = line[0];
                            score1[k] = line[1];
                            team2[k] = line[2];
                            score2[k] = line[3];
                            msg[k] = line[4];
                            k++;
                        }else{
                            
                            //break;
                        }
                    }
                }catch(Exception ee){
                    JOptionPane.showMessageDialog(null, "No Macth found in this date");
                }
                    
                                   
                                            
                    JTable table = new JTable(tableModel);
                    tableModel.addRow(objs2);
                    System.out.println(len);
                    
                    for (int kk = 0; kk < len; kk++) {
                        
                            Object[] objs = {team1[kk],score1[kk],team2[kk],score2[kk],msg[kk]};
                            tableModel.addRow(objs);                                                                                                                           
                    }
                    
                    len = 0;
                    f6.setTitle("Sorting on the basis of Date");
                    
                    f6.add(table);
                    f6.setSize(1200,700);    
                    f6.setVisible(true);
            }  
            });
                
                f.add(btnsearch);
                
                JLabel lbl = new JLabel("Date Format: dd-mm-yyyy");
                lbl.setBounds(140, 420, 150, 50);
                f.add(lbl);
                f.setSize(800,500);//400 width and 500 height  
                f.setLayout(null);//using no layout managers  
                f.setVisible(true);//making the frame visible     
            }else if (choice == 7) {
                System.exit(0);
            }else{
                System.out.println("Enter correct Choice");
            }
        }
    }
    //For calculating random date.
public static int randBetween(int start, int end) {
        return start + (int)Math.round(Math.random() * (end - start));
    }
@Override
    public void sortingpoints(){
        int j = 0;
        Scanner input = new Scanner(System.in);
        Scanner inFile1;
                int increment = 0;
                
                String[] tempsArray = new String[10000];
                try {
                    inFile1 = new Scanner(new File("teamsData.txt")).useDelimiter(",\\s*");                    
                    while (inFile1.hasNext()) {
                      // find next line
                      tempsArray[increment] = inFile1.nextLine();
                      increment++;
                      len++;
                    }
                    inFile1.close();                   
                    for (String s : tempsArray) {
                        try{
                            if (s.equals(null)) {
                            break;
                            }else{
                                String[] list = s.split(",");
                                Clubs_Name[j] = list[0];
                                Clubs_Location[j] = list[1];
                                Clubs_Wins[j] = Integer.parseInt(list[2]) ;
                                Clubs_Draws[j] = Integer.parseInt(list[3]);
                                Clubs_Defeats[j] = Integer.parseInt(list[4]);
                                Clubs_Instance_Acheived_in_Season[j] = Integer.parseInt(list[5]);
                                Clubs_Goals_Received[j] = Integer.parseInt(list[6]);
                                Clubs_Goals_Scored[j] = Integer.parseInt(list[7]);
                                Clubs_Number[j] = Integer.parseInt(list[8]);
                                Clubs_No_Of_Mathes_Played[j] = Integer.parseInt(list[9]);
                                j++;
                                
                                //System.out.println(s);
                            }
                        }catch(Exception e){
                            
                        }
                    }
                    int n = j;  
                    int temp = 0;
                    String temp1 = "";
                    String temp2 = "";
                    int temp3 = 0;
                    int temp4 = 0;
                    int temp5 = 0;
                    int temp6= 0;
                    int temp7 = 0;
                    int temp8 = 0;
                    int temp9 = 0;
                    
                    for(int ii=0; ii < n; ii++){  
                        for(int jj=1; jj < (n-ii); jj++){  
                            if(Clubs_Number[jj-1] < Clubs_Number[jj]){  
                                temp = Clubs_Number[jj-1];  
                                Clubs_Number[jj-1] = Clubs_Number[jj];  
                                Clubs_Number[jj] = temp;
                                temp1 = Clubs_Name[jj-1];  
                                Clubs_Name[jj-1] = Clubs_Name[jj];  
                                Clubs_Name[jj] = temp1;
                                temp2 = Clubs_Location[jj-1];  
                                Clubs_Location[jj-1] = Clubs_Location[jj];  
                                Clubs_Location[jj] = temp2;
                                temp3 = Clubs_Wins[jj-1];  
                                Clubs_Wins[jj-1] = Clubs_Wins[jj];  
                                Clubs_Wins[jj] = temp3;
                                temp4 = Clubs_Draws[jj-1];  
                                Clubs_Draws[jj-1] = Clubs_Draws[jj];  
                                Clubs_Draws[jj] = temp4;
                                temp5 = Clubs_Defeats[jj-1];  
                                Clubs_Defeats[jj-1] = Clubs_Defeats[jj];  
                                Clubs_Defeats[jj] = temp5;
                                temp6 = Clubs_Instance_Acheived_in_Season[jj-1];  
                                Clubs_Instance_Acheived_in_Season[jj-1] = Clubs_Instance_Acheived_in_Season[jj];  
                                Clubs_Instance_Acheived_in_Season[jj] = temp6;
                                temp7 = Clubs_Goals_Received[jj-1];  
                                Clubs_Goals_Received[jj-1] = Clubs_Goals_Received[jj];  
                                Clubs_Goals_Received[jj] = temp7;
                                temp8 = Clubs_Goals_Scored[jj-1];  
                                Clubs_Goals_Scored[jj-1] = Clubs_Goals_Scored[jj];  
                                Clubs_Goals_Scored[jj] = temp8;
                                temp9 = Clubs_No_Of_Mathes_Played[jj-1];  
                                Clubs_No_Of_Mathes_Played[jj-1] = Clubs_No_Of_Mathes_Played[jj];  
                                Clubs_No_Of_Mathes_Played[jj] = temp9;
                            }      
                        }
                    }                                                                                                           
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Premier_League_Manager.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                for (int k = 0; k < len; k++) {
                    System.out.println((k+1)+". Name: "+Clubs_Name[k]+" , Location: "+Clubs_Location[k]+" , Wins: "+Clubs_Wins[k]+" , Draws: "+Clubs_Draws[k]+" , Defeats: "+Clubs_Defeats[k]+" , Instanse Acheived in season: "+Clubs_Instance_Acheived_in_Season[k]+" , Goals Received: "+Clubs_Goals_Received[k]+" , Goals Scored: "+Clubs_Goals_Scored[k]+" , Points: "+Clubs_Number[k]+" , Number of Matches: "+Clubs_No_Of_Mathes_Played[k]);
                }            
    }
    
@Override
    public void sortingGoalScore(){
        int j = 0;
        Scanner input = new Scanner(System.in);
        Scanner inFile1;
                int increment = 0;
                
                String[] tempsArray = new String[10000];
                try {
                    inFile1 = new Scanner(new File("teamsData.txt")).useDelimiter(",\\s*");                    
                    while (inFile1.hasNext()) {
                      // find next line
                      tempsArray[increment] = inFile1.nextLine();
                      increment++;
                      len++;
                    }
                    inFile1.close();                   
                    for (String s : tempsArray) {
                        try{
                            if (s.equals(null)) {
                            break;
                            }else{
                                String[] list = s.split(",");
                                Clubs_Name[j] = list[0];
                                Clubs_Location[j] = list[1];
                                Clubs_Wins[j] = Integer.parseInt(list[2]) ;
                                Clubs_Draws[j] = Integer.parseInt(list[3]);
                                Clubs_Defeats[j] = Integer.parseInt(list[4]);
                                Clubs_Instance_Acheived_in_Season[j] = Integer.parseInt(list[5]);
                                Clubs_Goals_Received[j] = Integer.parseInt(list[6]);
                                Clubs_Goals_Scored[j] = Integer.parseInt(list[7]);
                                Clubs_Number[j] = Integer.parseInt(list[8]);
                                Clubs_No_Of_Mathes_Played[j] = Integer.parseInt(list[9]);
                                j++;
                                
                                //System.out.println(s);
                            }
                        }catch(Exception e){
                            
                        }
                    }
                    int n = j;  
                    int temp = 0;
                    String temp1 = "";
                    String temp2 = "";
                    int temp3 = 0;
                    int temp4 = 0;
                    int temp5 = 0;
                    int temp6= 0;
                    int temp7 = 0;
                    int temp8 = 0;
                    int temp9 = 0;
                    
                    for(int ii=0; ii < n; ii++){  
                        for(int jj=1; jj < (n-ii); jj++){  
                            if(Clubs_Goals_Scored[jj-1] < Clubs_Goals_Scored[jj]){  
                                temp = Clubs_Number[jj-1];  
                                Clubs_Number[jj-1] = Clubs_Number[jj];  
                                Clubs_Number[jj] = temp;
                                temp1 = Clubs_Name[jj-1];  
                                Clubs_Name[jj-1] = Clubs_Name[jj];  
                                Clubs_Name[jj] = temp1;
                                temp2 = Clubs_Location[jj-1];  
                                Clubs_Location[jj-1] = Clubs_Location[jj];  
                                Clubs_Location[jj] = temp2;
                                temp3 = Clubs_Wins[jj-1];  
                                Clubs_Wins[jj-1] = Clubs_Wins[jj];  
                                Clubs_Wins[jj] = temp3;
                                temp4 = Clubs_Draws[jj-1];  
                                Clubs_Draws[jj-1] = Clubs_Draws[jj];  
                                Clubs_Draws[jj] = temp4;
                                temp5 = Clubs_Defeats[jj-1];  
                                Clubs_Defeats[jj-1] = Clubs_Defeats[jj];  
                                Clubs_Defeats[jj] = temp5;
                                temp6 = Clubs_Instance_Acheived_in_Season[jj-1];  
                                Clubs_Instance_Acheived_in_Season[jj-1] = Clubs_Instance_Acheived_in_Season[jj];  
                                Clubs_Instance_Acheived_in_Season[jj] = temp6;
                                temp7 = Clubs_Goals_Received[jj-1];  
                                Clubs_Goals_Received[jj-1] = Clubs_Goals_Received[jj];  
                                Clubs_Goals_Received[jj] = temp7;
                                temp8 = Clubs_Goals_Scored[jj-1];  
                                Clubs_Goals_Scored[jj-1] = Clubs_Goals_Scored[jj];  
                                Clubs_Goals_Scored[jj] = temp8;
                                temp9 = Clubs_No_Of_Mathes_Played[jj-1];  
                                Clubs_No_Of_Mathes_Played[jj-1] = Clubs_No_Of_Mathes_Played[jj];  
                                Clubs_No_Of_Mathes_Played[jj] = temp9;
                            }      
                        }
                    }                                                                                                           
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Premier_League_Manager.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                for (int k = 0; k < len; k++) {
                    System.out.println((k+1)+". Name: "+Clubs_Name[k]+" , Location: "+Clubs_Location[k]+" , Wins: "+Clubs_Wins[k]+" , Draws: "+Clubs_Draws[k]+" , Defeats: "+Clubs_Defeats[k]+" , Instanse Acheived in season: "+Clubs_Instance_Acheived_in_Season[k]+" , Goals Received: "+Clubs_Goals_Received[k]+" , Goals Scored: "+Clubs_Goals_Scored[k]+" , Points: "+Clubs_Number[k]+" , Number of Matches: "+Clubs_No_Of_Mathes_Played[k]);
                }            
    }
    
@Override
    public void sortingWins(){
        int j = 0;
        Scanner input = new Scanner(System.in);
        Scanner inFile1;
                int increment = 0;
                
                String[] tempsArray = new String[10000];
                try {
                    inFile1 = new Scanner(new File("teamsData.txt")).useDelimiter(",\\s*");                    
                    while (inFile1.hasNext()) {
                      // find next line
                      tempsArray[increment] = inFile1.nextLine();
                      increment++;
                      len++;
                    }
                    inFile1.close();                   
                    for (String s : tempsArray) {
                        try{
                            if (s.equals(null)) {
                            break;
                            }else{
                                String[] list = s.split(",");
                                Clubs_Name[j] = list[0];
                                Clubs_Location[j] = list[1];
                                Clubs_Wins[j] = Integer.parseInt(list[2]) ;
                                Clubs_Draws[j] = Integer.parseInt(list[3]);
                                Clubs_Defeats[j] = Integer.parseInt(list[4]);
                                Clubs_Instance_Acheived_in_Season[j] = Integer.parseInt(list[5]);
                                Clubs_Goals_Received[j] = Integer.parseInt(list[6]);
                                Clubs_Goals_Scored[j] = Integer.parseInt(list[7]);
                                Clubs_Number[j] = Integer.parseInt(list[8]);
                                Clubs_No_Of_Mathes_Played[j] = Integer.parseInt(list[9]);
                                j++;
                                
                                //System.out.println(s);
                            }
                        }catch(Exception e){
                            
                        }
                    }
                    int n = j;  
                    int temp = 0;
                    String temp1 = "";
                    String temp2 = "";
                    int temp3 = 0;
                    int temp4 = 0;
                    int temp5 = 0;
                    int temp6= 0;
                    int temp7 = 0;
                    int temp8 = 0;
                    int temp9 = 0;
                    
                    for(int ii=0; ii < n; ii++){  
                        for(int jj=1; jj < (n-ii); jj++){  
                            if(Clubs_Wins[jj-1] < Clubs_Wins[jj]){  
                                temp = Clubs_Number[jj-1];  
                                Clubs_Number[jj-1] = Clubs_Number[jj];  
                                Clubs_Number[jj] = temp;
                                temp1 = Clubs_Name[jj-1];  
                                Clubs_Name[jj-1] = Clubs_Name[jj];  
                                Clubs_Name[jj] = temp1;
                                temp2 = Clubs_Location[jj-1];  
                                Clubs_Location[jj-1] = Clubs_Location[jj];  
                                Clubs_Location[jj] = temp2;
                                temp3 = Clubs_Wins[jj-1];  
                                Clubs_Wins[jj-1] = Clubs_Wins[jj];  
                                Clubs_Wins[jj] = temp3;
                                temp4 = Clubs_Draws[jj-1];  
                                Clubs_Draws[jj-1] = Clubs_Draws[jj];  
                                Clubs_Draws[jj] = temp4;
                                temp5 = Clubs_Defeats[jj-1];  
                                Clubs_Defeats[jj-1] = Clubs_Defeats[jj];  
                                Clubs_Defeats[jj] = temp5;
                                temp6 = Clubs_Instance_Acheived_in_Season[jj-1];  
                                Clubs_Instance_Acheived_in_Season[jj-1] = Clubs_Instance_Acheived_in_Season[jj];  
                                Clubs_Instance_Acheived_in_Season[jj] = temp6;
                                temp7 = Clubs_Goals_Received[jj-1];  
                                Clubs_Goals_Received[jj-1] = Clubs_Goals_Received[jj];  
                                Clubs_Goals_Received[jj] = temp7;
                                temp8 = Clubs_Goals_Scored[jj-1];  
                                Clubs_Goals_Scored[jj-1] = Clubs_Goals_Scored[jj];  
                                Clubs_Goals_Scored[jj] = temp8;
                                temp9 = Clubs_No_Of_Mathes_Played[jj-1];  
                                Clubs_No_Of_Mathes_Played[jj-1] = Clubs_No_Of_Mathes_Played[jj];  
                                Clubs_No_Of_Mathes_Played[jj] = temp9;
                            }      
                        }
                    }                                                                                                           
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Premier_League_Manager.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                for (int k = 0; k < len; k++) {
                    System.out.println((k+1)+". Name: "+Clubs_Name[k]+" , Location: "+Clubs_Location[k]+" , Wins: "+Clubs_Wins[k]+" , Draws: "+Clubs_Draws[k]+" , Defeats: "+Clubs_Defeats[k]+" , Instanse Acheived in season: "+Clubs_Instance_Acheived_in_Season[k]+" , Goals Received: "+Clubs_Goals_Received[k]+" , Goals Scored: "+Clubs_Goals_Scored[k]+" , Points: "+Clubs_Number[k]+" , Number of Matches: "+Clubs_No_Of_Mathes_Played[k]);
                }            
    }
}  

