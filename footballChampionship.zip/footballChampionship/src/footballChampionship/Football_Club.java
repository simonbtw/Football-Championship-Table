package footballChampionship;

public class Football_Club extends Sports_Club{
    String Club_Name;
    String Club_Location;
    int Club_Wins;
    int Club_Draws;
    int Club_Defeats;
    int Club_Instance_Acheived_in_Season;
    int Club_Goals_Received;
    int Club_Goals_Scored;
    int Club_Number;
    int Club_No_Of_Mathes_Played;
    
    String[] Clubs_Name;
    String[] Clubs_Location;
    int[] Clubs_Wins;
    int[] Clubs_Draws;
    int[] Clubs_Defeats;
    int[] Clubs_Instance_Acheived_in_Season;
    int[] Clubs_Goals_Received;
    int[] Clubs_Goals_Scored;
    int[] Clubs_Number;
    int[] Clubs_No_Of_Mathes_Played;
}
